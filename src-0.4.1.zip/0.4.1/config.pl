
% config.pl
% Prolog Server Pages configuration file

% During installation, this file is copied into your %APPDATA%\PrologServerPages directory.

:- set_prolog_flag(http_reporting, [error, warning]).

